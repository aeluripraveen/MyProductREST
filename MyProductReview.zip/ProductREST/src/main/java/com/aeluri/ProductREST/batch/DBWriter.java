package com.aeluri.ProductREST.batch;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aeluri.ProductREST.model.Product;
import com.aeluri.ProductREST.repository.ProductRepository;
@Component
public class DBWriter implements ItemWriter<Product>{
	@Autowired
	private ProductRepository productRepository;
	

	@Override
	public void write(List<? extends Product> products) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Saved to DB"+products );
		productRepository.saveAll(products);
	}

}
