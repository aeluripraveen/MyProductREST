package com.aeluri.ProductREST.controller;

import java.util.Date;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aeluri.ProductREST.model.Product;
import com.aeluri.ProductREST.service.ProductDAO;

@RestController
@RequestMapping("/")
public class ProductController {
	@Autowired
	ProductDAO productDAO;

	@PostMapping("/products")
	public Product createProduct(@Valid @RequestBody Product product) {
		product.setUploadTime(new Date());
		return productDAO.saveProdut(product);
	}

	@GetMapping("/products")
	public List<Product> getAllProducts() {
		System.out.println("Collecting.. from Controller");
		return productDAO.findAll();
	}

	@GetMapping("/products/{id}")
	public ResponseEntity<Product> getProduct(@PathVariable(value = "id") int product_id) {
		Product product = productDAO.findOne(product_id);
		if (product == null) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok().body(product);
	}

	@PutMapping("/products/{id}")
	public ResponseEntity<Product> updateProduct(@PathVariable(value = "id") int product_id,
			@Valid @RequestBody Product prodDetails) {
		Product product = productDAO.findOne(product_id);
		if (product == null) {
			return ResponseEntity.notFound().build();
		}
		
		Product updateProduct = productDAO.saveProdut(prodDetails);
		return ResponseEntity.ok().body(updateProduct);
	}

	@DeleteMapping("/products/{id}")
	public ResponseEntity<Product> deleteProduct(@PathVariable(value = "id") int product_id) {
		Product product = productDAO.findOne(product_id);
		if (product == null) {
			return ResponseEntity.notFound().build();
		}

		productDAO.delete(product);
		return ResponseEntity.ok().build();
	}

}