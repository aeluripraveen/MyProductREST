package com.aeluri.ProductREST.model;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;
@Entity
@Table(name="Product")
@EntityListeners(AuditingEntityListener.class)
public class Product {
	
	@Override
	public String toString() {
		return "Product [product_id=" + product_id + ", source_product_id=" + source_product_id + ", product_name="
				+ product_name + ", source=" + source + ", source_review_id=" + source_review_id + ", reviewer_name="
				+ reviewer_name + ", star_rating=" + star_rating + ", review_date=" + review_date + ", review_tag="
				+ review_tag + ", reviewer_id=" + reviewer_id + ", category_id=" + category_id + ", review_url="
				+ review_url + ", review_text=" + review_text + ", uploadTime=" + uploadTime + "]";
	}
	@Id
	private int product_id;
	private String source_product_id;
	private String product_name;
	private int source;
	private String source_review_id;
	private String reviewer_name;
	private String star_rating;
	private Date review_date;
	private String review_tag;
	private int reviewer_id;
	private int category_id;
	private String review_url;
	private String review_text;
	private Date uploadTime;
	
	public String getSource_product_id() {
		return source_product_id;
	}
	public void setSource_product_id(String source_product_id) {
		this.source_product_id = source_product_id;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public String getSource_review_id() {
		return source_review_id;
	}
	public void setSource_review_id(String source_review_id) {
		this.source_review_id = source_review_id;
	}
	public String getReviewer_name() {
		return reviewer_name;
	}
	public void setReviewer_name(String reviewer_name) {
		this.reviewer_name = reviewer_name;
	}
	public String getStar_rating() {
		return star_rating;
	}
	public void setStar_rating(String star_rating) {
		this.star_rating = star_rating;
	}
	public String getReview_tag() {
		return review_tag;
	}	
		
	public void setReview_tag(String review_tag) {
		this.review_tag = review_tag;
	}
	
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Product(int product_id, String source_product_id, String product_name, int source,
			String source_review_id, String reviewer_name, String star_rating, Date review_date, String review_tag,
			int reviewer_id, int category_id, String review_url, String review_text, Date uploadTime) {
		super();
		this.product_id = product_id;
		this.source_product_id = source_product_id;
		this.product_name = product_name;
		this.source = source;
		this.source_review_id = source_review_id;
		this.reviewer_name = reviewer_name;
		this.star_rating = star_rating;
		this.review_date = review_date;
		this.review_tag = review_tag;
		this.reviewer_id = reviewer_id;
		this.category_id = category_id;
		this.review_url = review_url;
		this.review_text = review_text;
		this.uploadTime = uploadTime;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	
	public int getSource() {
		return source;
	}
	public void setSource(int source) {
		this.source = source;
	}
	public Date getReview_date() {
		return review_date;
	}
	public void setReview_date(Date review_date) {
		this.review_date = review_date;
	}
	public int getReviewer_id() {
		return reviewer_id;
	}
	public void setReviewer_id(int reviewer_id) {
		this.reviewer_id = reviewer_id;
	}
	public int getCategory_id() {
		return category_id;
	}
	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}
	public Date getUploadTime() {
		return uploadTime;
	}
	public void setUploadTime(Date uploadTime) {
		this.uploadTime = uploadTime;
	}
	public String getReview_url() {
		return review_url;
	}
	public void setReview_url(String review_url) {
		this.review_url = review_url;
	}
	public String getReview_text() {
		return review_text;
	}
	public void setReview_text(String review_text) {
		this.review_text = review_text;
	}
}
