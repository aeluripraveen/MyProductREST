package com.aeluri.ProductREST.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aeluri.ProductREST.exception.ProductNotFoundException;
import com.aeluri.ProductREST.model.Product;
import com.aeluri.ProductREST.repository.ProductRepository;


@Service
public class ProductDAO {
	@Autowired
	ProductRepository productRepository;
	
	public Product saveProdut(Product product) {
		return productRepository.save(product);
	}
	public List<Product> findAll(){
		
		return productRepository.findAll();
	}
	public Product findOne(int product_id ) {
		
		if(productRepository.findById(product_id).isPresent()) {
				return productRepository.findById(product_id).get();
		} else
			throw new ProductNotFoundException("Product not found with ID:"+ product_id);
		//return productRepository.findById(product_id);
	}
	public void delete(Product product) {
		productRepository.delete(product);
	}

}
