package com.aeluri.ProductREST.exception;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

import com.aeluri.ProductREST.model.ErrorDetails;

@RestController
@ControllerAdvice
public class RESTExceptionHandler {
	@ExceptionHandler(value=ProductNotFoundException.class)
	
	public ResponseEntity<ErrorDetails> handleProductNotFoundException() {
		ErrorDetails error= new ErrorDetails(400, "Not Found", new Date());
		return new ResponseEntity<ErrorDetails>(error,HttpStatus.BAD_REQUEST);
	}
}
